from django.shortcuts import render
from.models import Tweet
from .forms import TweetForm
from django.shortcuts import get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login as login
from .forms import UserRegisterForm
from django.db.models import Q
from datetime import datetime

# Create your views here.
def index(request):
    return render(request, 'index.html'); 
def tweet_list(request):
    tweets = Tweet.objects.all().order_by('-created_at')
    return render(request, 'tweet_list.html', {'tweets': tweets})

@login_required
def tweet_create(request):
    if request.method == 'POST':
        form = TweetForm(request.POST, request.FILES)
        if form.is_valid():
            tweet = form.save(commit=False)
            tweet.user = request.user
            tweet.save()
            print("saved")
            return redirect('tweet_list')
    else:
        print("NOT SAVED ")
        form = TweetForm()
    return render(request, 'tweet_form.html', {'form': form})

@login_required
def tweet_edit(request,tweet_id):
    tweet = get_object_or_404(Tweet, pk=tweet_id, user=request.user)
    if request.method == 'POST':
        form = TweetForm(request.POST, request.FILES, instance=tweet)
        if form.is_valid():
            tweet = form.save(commit=False)
            tweet.user = request.user
            form.save()
            return redirect('tweet_list')
    else:
        form = TweetForm(instance=tweet)
    return render(request, 'tweet_form.html', {'form': form})

@login_required
def tweet_delete(request, tweet_id):
    tweet = get_object_or_404(Tweet, pk=tweet_id, user=request.user)
    if request.method == 'POST':
        tweet.delete()
        return redirect('tweet_list')
    return render(request, 'tweet_confirm_delete.html', {'tweet': tweet})

def register(request):
    if request.method == 'POST':
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.set_password(form.cleaned_data['password1'])
            form.save()
            login(request, user)
            return redirect('tweet_list')
    else:
        form = UserRegisterForm()
    return render(request, 'registration/register.html', {'form': form})

print("Hello, world!")

def search(request):
    query = request.GET.get('search')
    print("Search query:", query)

    if not query:
        return render(request, 'search.html', {'tweets': [], 'query': ''})

    # Search by text or username
    tweets = Tweet.objects.filter(
        Q(text__icontains=query) | Q(user__username__icontains=query)
    )

    # Try to parse the query as a date/time in your display format
    date_formats = [
        "%B %d, %Y, %I:%M %p",  # November 14, 2025, 12:16 PM
        "%B %d, %Y",             # November 14, 2025
        "%d %B",                 # 14 November
        "%B %d",                 # November 14
        "%B %Y",                 # November 2025
        "%B",                    # November
        "%d",                    # day only (14)
        "%Y",                    # year only (2025)
        "%I:%M %p",              # 12:16 PM
    ]

    for fmt in date_formats:
        try:
            dt = datetime.strptime(query, fmt)
            # Determine filter based on format
            if fmt == "%I:%M %p":  # only time
                tweets_by_time = Tweet.objects.filter(
                    created_at__hour=dt.hour,
                    created_at__minute=dt.minute
                )
            elif fmt in ["%B %d", "%d %B"]:  # day + month
                tweets_by_time = Tweet.objects.filter(
                    created_at__month=dt.month,
                    created_at__day=dt.day
                )
            elif fmt == "%B %Y":  # month + year
                tweets_by_time = Tweet.objects.filter(
                    created_at__month=dt.month,
                    created_at__year=dt.year
                )
            elif fmt == "%B":  # month only
                tweets_by_time = Tweet.objects.filter(created_at__month=dt.month)
            elif fmt == "%d":  # day only
                tweets_by_time = Tweet.objects.filter(created_at__day=dt.day)
            elif fmt == "%Y":  # year only
                tweets_by_time = Tweet.objects.filter(created_at__year=dt.year)
            elif fmt == "%B %d, %Y, %I:%M %p":  # full datetime
                tweets_by_time = Tweet.objects.filter(created_at=dt)
            else:  # full date without time "%B %d, %Y"
                tweets_by_time = Tweet.objects.filter(created_at__date=dt.date())

            tweets = tweets.union(tweets_by_time)
            break  # stop at first format that works
        except ValueError:
            continue  # try next format

    params = {'tweets': tweets, 'query': query}
    return render(request, 'search.html', params)       
